select * from student_user su ;

INSERT INTO student_user (user_code, username,age,email, password, user_id)
VALUES ( 100,'james', '30','james@gmail.com','Test@123', 'USER_001');

INSERT INTO student_user  (user_code, username,age,email, password, user_id)
VALUES (101,'ken',  '30','james@gmail.com','Test@123', 'USER_002');

INSERT INTO student_user  (user_code, username,age,email, password, user_id)
VALUES (102, 'dennis',  '30','james@gmail.com','Test@123', 'USER_003');