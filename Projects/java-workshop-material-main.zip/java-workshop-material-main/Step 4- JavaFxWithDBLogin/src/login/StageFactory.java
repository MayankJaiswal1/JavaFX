package login;

import javafx.stage.Stage;

public class StageFactory {
	
	public static Stage stageProvidedByJfx;

}
