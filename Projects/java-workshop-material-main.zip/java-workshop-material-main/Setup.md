Install below applications

1. Latest JDK
2. Latest eclipse 
3. MySQL DB (remember username & password given while installation)
4. JavaFx library 
	https://gluonhq.com/products/javafx/
5. Javafx Scene builder from
	https://gluonhq.com/products/scene-builder/
6. MySql Workbench
7. Postman
